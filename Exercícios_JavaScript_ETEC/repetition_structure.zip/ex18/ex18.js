//Escreva um programa que exiba os números de 1 a 100 na tela em ordem decrescente.
var num = 100;
while (num >= 1 ) {
    document.writeln(`<p>${num}</p>`);
    num--;
}
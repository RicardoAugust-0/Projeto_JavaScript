var num = 0

while (num <= 2000) {
    document.writeln(num);
    num++;
}